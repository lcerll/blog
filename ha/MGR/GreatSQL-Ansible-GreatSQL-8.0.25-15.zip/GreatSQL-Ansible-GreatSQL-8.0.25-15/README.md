# GreatSQL-Ansible

## 介绍
利用ansible一键安装GreatSQL并完成MGR部署。

## 文档
[ansible一键安装GreatSQL并构建MGR集群](https://gitee.com/GreatSQL/GreatSQL-Ansible/wikis/ansible%E4%B8%80%E9%94%AE%E5%AE%89%E8%A3%85GreatSQL%E5%B9%B6%E6%9E%84%E5%BB%BAMGR%E9%9B%86%E7%BE%A4?sort_id=4249938)