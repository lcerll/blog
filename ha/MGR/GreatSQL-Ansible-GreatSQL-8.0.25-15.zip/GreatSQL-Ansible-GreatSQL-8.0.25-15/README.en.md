GreatSQL-Ansible

####Introduction

How to install GreatSQL and setup a MGR cluster by ansible.
